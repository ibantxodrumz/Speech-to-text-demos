import assemblyai as aai
import os
import shutil
import time

# Set the AssemblyAI API key
aai.settings.api_key = f"b2d9c56c7a124fb98c3f744f653409ba"

def transcribe_audio_files(input_folder, output_folder):
    # Create a Transcriber instance
    transcriber = aai.Transcriber()
    
    # Ensure the output folder exists or create it if it doesn't
    os.makedirs(output_folder, exist_ok=True)

    start_time = time.perf_counter()  # Record the start time
    
    # Iterate through each audio file in the input folder and transcribe it
    for filename in os.listdir(input_folder):
        if filename.endswith('.mp3'):
            audio_file_path = os.path.join(input_folder, filename)
            transcript = transcriber.transcribe(audio_file_path)
            
            # Create the output file path by joining the output folder and the original filename
            output_file_path = os.path.join(output_folder, filename.replace('.mp3', '.txt'))
            
            # Save the transcription to a text file with the same name as the audio file
            with open(output_file_path, 'w') as output_file:
                output_file.write(transcript.text)
    
            print(f"Transcription for {filename} saved to {output_file_path}")

    end_time = time.perf_counter()  # Record the end time
    elapsed_time = end_time - start_time
    print(f"Time taken for transcription: {elapsed_time:.2f} seconds")

def find_and_copy_matching_files(prompts_file_path, transcriptions_folder, check_folder):
    # Read and print the prompts from the text file (make sure they are in different lines)
    with open(prompts_file_path, 'r', encoding='utf-8', errors='ignore') as prompts_file:
        prompts = [p.strip() for p in prompts_file.readlines()]
        print("Prompts from the file:")
        for prompt in prompts:
            print(prompt)
    
    # Ensure the 'check' folder exists or create it if it doesn't
    os.makedirs(check_folder, exist_ok=True)

    start_time = time.perf_counter()  # Record the start time
    
    # Iterate through all the transcription files
    matching_file_count = 0
    for filename in os.listdir(transcriptions_folder):
        file_path = os.path.join(transcriptions_folder, filename)
        if os.path.isfile(file_path):
            # Specify the encoding when reading the transcription file and 'ignore' error handler
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
                content = file.read()
                # Inspect the text of the files against the prompts
                if any(prompt in content for prompt in prompts):
                    matching_file_count += 1
                    # Copy the matching file to the 'check' folder
                    shutil.copy(file_path, os.path.join(check_folder, filename))
    
    end_time = time.perf_counter()  # Record the end time
    elapsed_time = end_time - start_time
    print(f"Time taken for matching and copying: {elapsed_time:.2f} seconds")
    
    # Display the count of matching files
    print(f"{matching_file_count} file(s) matching the prompts have been copied to the 'check' folder.")

if __name__ == "__main__":
    input_folder = '/Users/ivansanz/Desktop/prueba audio/'
    output_folder = '/Users/ivansanz/Desktop/prueba audio/transcriptions/'
    prompts_file_path = '/Users/ivansanz/Desktop/prueba audio/Prompts drums.txt'
    transcriptions_folder = '/Users/ivansanz/Desktop/prueba audio/transcriptions/'
    check_folder = '/Users/ivansanz/Desktop/prueba audio/check/'
    
    transcribe_audio_files(input_folder, output_folder)
    find_and_copy_matching_files(prompts_file_path, transcriptions_folder, check_folder)

