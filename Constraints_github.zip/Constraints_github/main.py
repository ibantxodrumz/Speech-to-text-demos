# This file is the main entry point for the project and is used to run the data pipeline

import argparse
from datetime import datetime, timedelta
import urllib3
from urllib3.exceptions import InsecureRequestWarning

# Suppress only the single InsecureRequestWarning from urllib3
urllib3.disable_warnings(InsecureRequestWarning)

from dotenv import load_dotenv

# load environment variables from .env file
load_dotenv()

from src.fetch_data import DataFetcher
from src.clean_data import DataCleaner
from src.agg_data import DataAggregator
import pandas as pd
import time

# disable SettingWithCopyWarning
pd.options.mode.chained_assignment = None


def main(start_date, end_date):
    # specify the base url
    base_url = "https://data.elexon.co.uk/bmrs/api/v1/"

    # define dictionary for endpoints
    dict_ep = {
        "PN_ep": "datasets/PN/stream",
        "MELS_ep": "datasets/MELS/stream",
        "B1610_ep": "datasets/B1610/stream",  # metered output
        "BID_ep": "balancing/settlement/acceptance/volumes/all/bid",  # volume of accepted bids
        "OFFER_ep": "balancing/settlement/acceptance/volumes/all/offer",  # volume of accepted offers
    }

    fetcher = DataFetcher(base_url)
    cleaner = DataCleaner()

    for day in pd.date_range(start=start_date, end=end_date):
        ####### fetch and save the raw data by day #######
        for ep in dict_ep.keys():
            fetcher.fetch_data(dict_ep[ep], day)

        ####### clean and save the processed day by day #######
        dict_cleaned = {}  # initiate a dict for each day
        for name in [key.split("_")[0] for key in dict_ep.keys()]:
            df = cleaner.clean_dataset(name, day)
            dict_cleaned[name] = df
        # combine all and save to path
        cleaner.combine_all(dict_cleaned, day)

        # sleep for 0.1 second to avoid rate limiting
        time.sleep(0.1)

    ####### aggregate metrics and save to output #######
    aggregator = DataAggregator()
    aggregator.cal_agg()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PN Accuracy Processing")
    parser.add_argument(
        "--start-date",
        type=str,
        default="2023-01-01",
        help="Start date in YYYY-MM-DD format",
    )
    parser.add_argument(
        "--end-date",
        type=str,
        default=(datetime.now() - timedelta(days=11)).strftime("%Y-%m-%d"),
        help="End date in YYYY-MM-DD format",
    )
    args = parser.parse_args()
    main(args.start_date, args.end_date)
