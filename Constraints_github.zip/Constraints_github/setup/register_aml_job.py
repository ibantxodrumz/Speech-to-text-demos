import argparse
from datetime import datetime, timedelta
from azure.ai.ml import MLClient
from azure.ai.ml.dsl import pipeline
from azure.ai.ml.entities import Environment, CommandComponent, CronTrigger, JobSchedule
from azure.identity import AzureCliCredential


def main():

    # Parse command-line arguments
    parser = argparse.ArgumentParser(
        description="Configure and register an AML environment, component, and scheduled job."
    )
    parser.add_argument(
        "--environment",
        type=str,
        default="pn-accuracy",
        help="Name of the Azure ML environment.",
    )
    parser.add_argument(
        "--subscription_id",
        type=str,
        default="8503abbb-1510-48bb-a9da-8bcb2cb1ceb2",
        help="Azure subscription ID.",
    )
    parser.add_argument(
        "--resource_group",
        type=str,
        default="5784c-fof-uks-ncmm-rg",
        help="Azure resource group.",
    )
    parser.add_argument(
        "--workspace",
        type=str,
        default="aae-fof-uks-aaencmm-mlw-01",
        help="Azure ML workspace name.",
    )

    args = parser.parse_args()

    environment_name = args.environment
    subscription_id = args.subscription_id
    resource_group = args.resource_group
    workspace = args.workspace

    # Create an MLClient instance
    ml_client = MLClient(
        AzureCliCredential(), subscription_id, resource_group, workspace
    )

    # Define the environment

    env = Environment(
        image="mcr.microsoft.com/azureml/openmpi4.1.0-ubuntu20.04:latest",
        conda_file="setup/conda.yaml",
        name=environment_name,
        description=f"Environment created to run {environment_name} project.",
    )

    registered_env = ml_client.environments.create_or_update(env)
    print(f"Registered environment: {registered_env.name}")

    # Define a component
    component = CommandComponent(
        name=f"run_main_{environment_name.replace("-", "_").lower()}",
        display_name=f"run_main_{environment_name.replace("-", "_").lower()}",
        description="Component to run pn accuracy project.",
        command=(
            "python -u main.py --start-date ${{inputs.start_date}} --end-date ${{inputs.end_date}}"
        ),
        environment=f"{registered_env.name}:{registered_env.version}",
        inputs={"start_date": {"type": "string"}, "end_date": {"type": "string"}},
        code=".",
        is_deterministic=False,
    )

    registered_component = ml_client.components.create_or_update(component)
    print(f"Registered component: {registered_component.name}")

    # List available compute targets and select a specific one
    compute_targets = ml_client.compute.list(compute_type="AmlCompute")
    compute_target = [
        target
        for target in list(compute_targets)
        if target.name.startswith("compclust")
    ][0]

    # Define a pipeline using the registered component and the selected compute target
    @pipeline(default_compute=compute_target.name)
    def my_pipeline(start_date: str, end_date: str):
        component_step = registered_component(start_date=start_date, end_date=end_date)
        return component_step

    experiment_name = f"{environment_name}-experiment"
    # Define the initial pipeline job to run from historical start date to current date - 10 days
    initial_pipeline_job = my_pipeline(
        start_date="2023-01-01",
        end_date=(datetime.now() - timedelta(days=11)).strftime("%Y-%m-%d"),
    )
    initial_pipeline_job.display_name = f"{environment_name}-initial-pipeline"
    initial_pipeline_job.experiment_name = experiment_name
    ml_client.jobs.create_or_update(initial_pipeline_job)

    # Define the daily pipeline job to run from current date - 10 days to current date - 10 days
    daily_pipeline_job = my_pipeline(
        start_date=(datetime.now() - timedelta(days=10)).strftime("%Y-%m-%d"),
        end_date=(datetime.now() - timedelta(days=10)).strftime("%Y-%m-%d"),
    )
    daily_pipeline_job.display_name = f"{environment_name}-daily-pipeline"
    daily_pipeline_job.experiment_name = experiment_name

    # Define the schedule for the daily pipeline job
    schedule_name = f"{environment_name}-daily-schedule"
    schedule_start_time = datetime.now()
    cron_trigger = CronTrigger(expression="0 0 * * *", start_time=schedule_start_time)
    job_schedule = JobSchedule(
        name=schedule_name, trigger=cron_trigger, create_job=daily_pipeline_job
    )

    # Create or update the job schedule
    job_schedule = ml_client.schedules.begin_create_or_update(
        schedule=job_schedule
    ).result()

    print(f"Scheduled pipeline: {job_schedule.name}")


if __name__ == "__main__":
    main()
