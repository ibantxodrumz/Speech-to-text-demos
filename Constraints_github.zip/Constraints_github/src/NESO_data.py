# Simple script to download NESO constraint data from their portal
# Based on the direct download URLs from the NESO data portal
# This file is placed in src/ folder

import requests
import os
from dotenv import load_dotenv

load_dotenv()

def download_neso_constraint_data():
    """
    Download NESO constraint flows and limits data
    """
    
    # Create data/input/NESO folder - use absolute path to ensure it goes to the right place
    # Get the current script directory (src/)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Go up one level to project root
    project_root = os.path.dirname(script_dir)
    # Create the NESO folder in the correct location
    neso_folder = os.path.join(project_root, "data", "input", "NESO")
    
    if not os.path.exists(neso_folder):
        os.makedirs(neso_folder, exist_ok=True)
        print(f"Created folder: {neso_folder}")
    else:
        print(f"Using existing folder: {neso_folder}")
    
    # Direct download URLs from NESO portal
    downloads = {
        "constraint_flows_limits.csv": "https://api.neso.energy/dataset/cf3cbc92-2d5d-4c2b-bd29-e11a21070b26/resource/38a18ec1-9e40-465d-93fb-301e80fd1352/download/day-ahead-constraints-limits-and-flow-output-v1.5.csv",
        "network_diagram_england_wales.pdf": "https://api.neso.energy/dataset/cf3cbc92-2d5d-4c2b-bd29-e11a21070b26/resource/bb6d6ec6-16d9-4be5-b32c-1a70c09fd871/download/ew-network-diagram-da-limit-boundaries.pdf",
        "network_diagram_scotland.pdf": "https://api.neso.energy/dataset/cf3cbc92-2d5d-4c2b-bd29-e11a21070b26/resource/3eb74046-3ffa-40c3-a541-b3cb00a44b1f/download/scotland-network-diagram-da-limit-boundaries.pdf"
    }
    
    print("Downloading NESO constraint data...")
    print("="*60)
    
    for filename, url in downloads.items():
        file_path = os.path.join(neso_folder, filename)
        
        try:
            print(f"Downloading {filename}...")
            response = requests.get(url, stream=True)
            response.raise_for_status()
            
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            file_size = os.path.getsize(file_path)
            print(f"Successfully downloaded {filename} ({file_size:,} bytes)")
            
        except requests.exceptions.RequestException as e:
            print(f"Error downloading {filename}: {str(e)}")
        except Exception as e:
            print(f"Unexpected error with {filename}: {str(e)}")
    
    print("\n" + "="*60)
    print("NESO data download completed!")
    print(f"\nFiles saved to: {neso_folder}/")
    print("- constraint_flows_limits.csv (main constraint data)")
    print("- network_diagram_england_wales.pdf (network diagrams)")
    print("- network_diagram_scotland.pdf (network diagrams)")


if __name__ == "__main__":
    download_neso_constraint_data()