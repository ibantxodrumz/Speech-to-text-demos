# Fetch actual bid/offer PRICES from Elexon API
# Based on the specific APIs mentioned in the NESO PDF

import requests
import urllib3
from urllib3.exceptions import InsecureRequestWarning

urllib3.disable_warnings(InsecureRequestWarning)

import pandas as pd
import time

if __name__ == "__main__":
    import utils as utils
else:
    import src.utils as utils

import config

if config.STORAGE_TYPE == "azure":
    from src.storage.azure_blob_storage import AzureBlobStorage as Storage
else:
    from src.storage.local_storage import LocalStorage as Storage
from dotenv import load_dotenv


class PriceDataFetcher:
    """
    Fetch actual bid/offer PRICES (not volumes) from Elexon API
    """

    def __init__(self, base_url):
        self.base_url = base_url
        if config.STORAGE_TYPE == "azure":
            self.storage = Storage(config.ACCOUNT_URL, config.CONTAINER_NAME, config.PROJECT_NAME)
        else:
            self.storage = Storage(config.BASE_DIR)

    def fetch_unit_prices(self, bmu_id, day):
        """
        Fetch unit-level bid/offer prices using from/to format
        Endpoint: /balancing-bid-offer-bmunit/{bmunit}/from/{from}/to/{to}
        """
        
        def get_with_retry(url, max_retries=5, delay=2):
            attempt = 0
            while attempt < max_retries:
                try:
                    r = requests.get(url, verify=False)
                    if r.status_code == 200:
                        print(f"Request successful on attempt {attempt + 1}.")
                        return r.json()
                    elif r.status_code == 400:
                        print(f"{r.status_code} bad request, try paginated fetching")
                        json_data = utils.paginated_fetch(url)
                        return json_data
                    else:
                        print(f"Attempt {attempt + 1} failed with status code {r.status_code}. Retrying in {delay} seconds...")
                except requests.exceptions.RequestException as e:
                    print(f"Attempt {attempt + 1} failed with error: {e}.")
                time.sleep(delay)
                attempt += 1
            print(f"Failed to get a 200 response after {max_retries} attempts.")
            return None

        From, To = utils.utc_to_localtime(day)
        endpoint = f"balancing-bid-offer-bmunit/{bmu_id}/from/{From}/to/{To}"
        url = f"{self.base_url}{endpoint}"
        
        print(f"Fetching prices for BMU {bmu_id} on {day.strftime('%Y-%m-%d')}")
        json_data = get_with_retry(url)
        
        if json_data:
            # Save using a modified endpoint name that includes the BMU
            modified_endpoint = f"balancing-bid-offer-bmunit-{bmu_id}"
            self.storage.save_raw_data(modified_endpoint, day, json_data)
            return True
        return False

    def fetch_market_prices(self, day):
        """
        Fetch market-wide bid/offer prices using correct query parameter format
        Endpoint: /balancing/bid-offer/all?settlementDate={settlementDate}&settlementPeriod={settlementPeriod}
        """
        
        def get_with_retry(url, max_retries=3, delay=1):
            attempt = 0
            while attempt < max_retries:
                try:
                    r = requests.get(url, verify=False)
                    if r.status_code == 200:
                        print(f"Request successful on attempt {attempt + 1}.")
                        return r.json()
                    elif r.status_code == 404:
                        print(f"404 - Period not found")
                        return None
                    else:
                        print(f"Attempt {attempt + 1} failed with status code {r.status_code}.")
                except requests.exceptions.RequestException as e:
                    print(f"Attempt {attempt + 1} failed with error: {e}.")
                time.sleep(delay)
                attempt += 1
            return None

        sett_date = day.strftime("%Y-%m-%d")
        all_price_data = []
        
        print(f"Fetching market prices for {sett_date}")
        
        # Fetch all settlement periods (1-50)
        for period in range(1, 51):
            url = f"{self.base_url}balancing/bid-offer/all?settlementDate={sett_date}&settlementPeriod={period}"
            period_data = get_with_retry(url)
            
            if period_data and 'data' in period_data:
                for record in period_data['data']:
                    record['fetched_settlement_period'] = period
                    record['fetched_settlement_date'] = sett_date
                all_price_data.extend(period_data['data'])
                if period <= 10:  # Show progress for first 10 periods
                    print(f"Period {period}: Found {len(period_data['data'])} price records")
            elif period <= 5:  # Show results for first 5 periods
                print(f"Period {period}: No data found")
            
            time.sleep(0.1)
        
        if all_price_data:
            self.storage.save_raw_data("balancing-bid-offer-all-prices", day, all_price_data)
            print(f"Total market price records: {len(all_price_data)}")
            return True
        else:
            print("No market price data found")
            return False


def main():
    load_dotenv()
    
    # CORRECTED: Use Elexon Insights API base URL for price data
    base_url = "https://insights.elexon.co.uk/api/v1/"
    
    # Test dates
    start_date = input("Enter start date (YYYY-MM-DD): ")
    end_date = input("Enter end date (YYYY-MM-DD): ")
    
    fetcher = PriceDataFetcher(base_url)
    
    for day in pd.date_range(start=start_date, end=end_date):
        print(f"\n--- Fetching PRICE data for {day.strftime('%Y-%m-%d')} ---")
        
        # Fetch market-wide prices - this should get ALL BMUs at once
        print("Fetching market-wide prices for all BMUs...")
        market_success = fetcher.fetch_market_prices(day)
        
        if market_success:
            print("Successfully collected market-wide price data for all participants")
        else:
            print("No market-wide price data available")
        
        time.sleep(0.5)


if __name__ == "__main__":
    main()