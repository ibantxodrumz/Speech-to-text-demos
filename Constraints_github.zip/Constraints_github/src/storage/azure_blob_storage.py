import pandas as pd
import os
from azure.storage.blob import BlobServiceClient
from azure.identity import ManagedIdentityCredential
from io import BytesIO


class AzureBlobStorage:

    def __init__(self, account_url, container_name, project_name):
        client_id = os.environ.get("DEFAULT_IDENTITY_CLIENT_ID")
        credential = ManagedIdentityCredential(client_id=client_id)
        self.blob_service_client = BlobServiceClient(account_url, credential=credential)
        self.container_client = self.blob_service_client.get_container_client(
            container_name
        )
        self.project_name = project_name
        self.metadata_folder = "meta"
        self.input_folder = "input"
        # output in consumable/pn-accuracy
        self.consumable_client = self.blob_service_client.get_container_client(
            "consumable"
        )

    def read_meta_data(self):
        """
        read bmu_id from metadata_folder
        """
        blob_name = (
            f"{self.project_name}/{self.metadata_folder}/full_list_of_wind_units.csv"
        )
        blob_client = self.container_client.get_blob_client(blob_name)
        data = blob_client.download_blob().readall()
        df = pd.read_csv(BytesIO(data))
        return df

    def read_raw_data(self, endpoint, day):
        """
        read daily file from input/endpoint
        """
        blob_name = (
            f"{self.project_name}/{self.input_folder}/{endpoint}/{endpoint}_{day}.csv"
        )
        blob_client = self.container_client.get_blob_client(blob_name)
        data = blob_client.download_blob().readall()
        df = pd.read_csv(BytesIO(data))
        return df

    def read_combined_file(self, file_name):
        """
        read combined file from input/combined
        """
        blob_name = f"{self.project_name}/{self.input_folder}/combined/{file_name}"
        blob_client = self.container_client.get_blob_client(blob_name)
        data = blob_client.download_blob().readall()
        df = pd.read_csv(BytesIO(data))
        return df

    def list_combined_files(self):
        """
        List all file names in pn-accuracy/input/combined folder
        """
        PREFIX = f"{self.project_name}/{self.input_folder}/combined/"
        blobs_list = self.container_client.list_blobs(name_starts_with=PREFIX)
        list_of_files = [
            blob.name[len(PREFIX) :] for blob in blobs_list
        ]  # ONLY RETURN THE FILE NAMES
        return list_of_files

    def save_meta_data(self, df, today):
        """
        save the registered capacity file in the metadata_folder
        """
        blob_name = f"{self.project_name}/{self.metadata_folder}/capacity_{today}.csv"
        blob_client = self.container_client.get_blob_client(blob_name)
        blob_client.upload_blob(df.to_csv(index=False), overwrite=True)
        print(f"Latest capacity data saved to {blob_name}\n")

    def save_raw_data(self, endpoint, day, json_data):
        """
        Save the raw data as a csv file in input/endpoint folder
        """
        segments = endpoint.split("/")
        names = ["PN", "MELS", "B1610", "bid", "offer"]
        name = [x for x in names if x in segments][0].upper()
        date_str = day.strftime("%Y-%m-%d")
        blob_name = (
            f"{self.project_name}/{self.input_folder}/{name}/{name}_{date_str}.csv"
        )
        blob_client = self.container_client.get_blob_client(blob_name)
        if endpoint.startswith("datasets"):
            df = pd.DataFrame(json_data)
        else:  # for bid/offer volumes
            df = pd.json_normalize(json_data["data"])
        # it looks like [PN data] from the previous day sp 48 is always included
        # make sure only the queried date is included
        df = df[df["settlementDate"] == date_str]
        blob_client.upload_blob(df.to_csv(index=False), overwrite=True)
        print(f"Data fetched and saved to {blob_name}\n")

    def save_combined_data(self, df, date_str):
        """
        save the combined data by date_str
        """
        blob_name = (
            f"{self.project_name}/{self.input_folder}/combined/combined_{date_str}.csv"
        )
        blob_client = self.container_client.get_blob_client(blob_name)
        blob_client.upload_blob(df.to_csv(index=False), overwrite=True)
        print(f"Combined data saved to {blob_name}\n")

    def save_agg(self, df, file_name):
        """
        save all aggregated data in the output_folder/internal
        """
        blob_name = f"{self.project_name}/internal/{file_name}"
        blob_client = self.consumable_client.get_blob_client(blob_name)
        blob_client.upload_blob(df.to_csv(index=False), overwrite=True)
        print(f"Aggregated data saved to {blob_name}\n")

    def save_publish(self, df, file_name):
        """
        save the published data in the output_folder/publish
        """
        blob_name = f"{self.project_name}/publish/{file_name}"
        blob_client = self.consumable_client.get_blob_client(blob_name)
        blob_client.upload_blob(df.to_csv(index=False), overwrite=True)
        print(f"Published data saved to {blob_name}\n")

    def delete_old_capacity_file(self):
        """
        remove existing capacity file before saving the new one
        """
        PREFIX = f"{self.project_name}/{self.metadata_folder}/"
        blobs_list = self.container_client.list_blobs(name_starts_with=PREFIX)
        for blob in blobs_list:
            if blob.name[len(PREFIX) :].startswith("capacity_") and blob.name[
                len(PREFIX) :
            ].endswith(".csv"):
                self.container_client.delete_blob(blob.name)
                print(f"The old file deleted: {blob.name}")
