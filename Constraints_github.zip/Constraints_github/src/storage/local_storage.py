import os
import pandas as pd


class LocalStorage:

    def __init__(self, base_dir):
        self.base_dir = base_dir

        # get the current script's directory (this is src/storage/)
        curr_dir = os.path.dirname(os.path.abspath(__file__))
        # go up two levels to reach root directory of the project
        root_dir = os.path.dirname(os.path.dirname(curr_dir))

        self.metadata_folder = os.path.join(root_dir, self.base_dir, "meta")
        if not os.path.exists(self.metadata_folder):
            os.makedirs(self.metadata_folder, exist_ok=True)

        self.input_folder = os.path.join(root_dir, self.base_dir, "input")
        if not os.path.exists(self.input_folder):
            os.makedirs(self.input_folder, exist_ok=True)

        self.output_folder = os.path.join(root_dir, self.base_dir, "output")
        if not os.path.exists(self.output_folder):
            os.makedirs(self.output_folder, exist_ok=True)

    def read_meta_data(self):
        """
        read bmu_id from metadata_folder
        """
        file_path = os.path.join(self.metadata_folder, f"full_list_of_wind_units.csv")
        df = pd.read_csv(file_path)
        return df

    def read_raw_data(self, endpoint, day):
        """
        read daily file from data/input/endpoint
        """
        file_path = os.path.join(self.input_folder, endpoint, f"{endpoint}_{day}.csv")
        df = pd.read_csv(file_path)
        return df

    def read_combined_file(self, file_name):
        """
        read combined file from data/input/combined
        """
        file_path = os.path.join(self.input_folder, "combined", file_name)
        df = pd.read_csv(file_path)
        return df

    def list_combined_files(self):
        """
        List all file names in data/input/combined folder
        """
        file_path = os.path.join(self.input_folder, "combined")
        list_of_files = os.listdir(file_path)
        return list_of_files

    def save_meta_data(self, df, today):
        """
        save the registered capacity file in the metadata_folder
        """
        file_path = os.path.join(self.metadata_folder, f"capacity_{today}.csv")
        df.to_csv(file_path, index=False)
        print(f"Latest capacity data saved to {file_path}\n")

    def save_raw_data(self, endpoint, day, json_data):
        """
        Save the raw data as a csv file in data/input/endpoint folder
        UPDATED FOR CONSTRAINT MONITORING: Handle new endpoint types
        """
        date_str = day.strftime("%Y-%m-%d")
        
        # Determine folder name and file prefix based on endpoint type
        if endpoint == "balancing/settlement/stack/all/offer":
            name = "MARKET_PRICES" 
        elif endpoint == "balancing-bid-offer-all":
            name = "MARKET_PRICES"
        elif endpoint.startswith("balancing-bid-offer-bmunit"):
            name = "UNIT_PRICES"
        elif endpoint == "balancing/settlement/acceptance/volumes/all/offer":
            name = "SYSTEM_FLAGS"
        elif endpoint == "balancing/settlement/acceptance/volumes/all/bid":
            name = "BID_VOLUMES"  
        elif endpoint.startswith("datasets"):
            # Handle any remaining dataset endpoints
            segments = endpoint.split("/")
            name = segments[-2] if len(segments) > 2 else segments[-1].upper()
        else:
            # Fallback: use the last part of the endpoint
            name = endpoint.split("/")[-1].upper().replace("-", "_")
        
        # Create endpoint folder
        ep_path = os.path.join(self.input_folder, name)
        if not os.path.exists(ep_path):
            os.makedirs(ep_path, exist_ok=True)
            
        file_path = os.path.join(ep_path, f"{name}_{date_str}.csv")
        
        # Convert to DataFrame
        if isinstance(json_data, list):
            df = pd.DataFrame(json_data)
        elif isinstance(json_data, dict) and 'data' in json_data:
            df = pd.json_normalize(json_data["data"])
        else:
            df = pd.json_normalize(json_data)
        
        # Filter to ensure only the queried date is included (if settlement date exists)
        if 'settlementDate' in df.columns:
            df = df[df["settlementDate"] == date_str]
        elif 'fetched_settlement_date' in df.columns:
            df = df[df["fetched_settlement_date"] == date_str]
        
        if not df.empty:
            df.to_csv(file_path, index=False)
            print(f"Data fetched and saved to {file_path} ({len(df)} records)")
        else:
            print(f"No data for {date_str} in endpoint {endpoint}")

    def save_combined_data(self, df, date_str):
        """
        save the combined data by date_str
        """
        # sub folder to store the combined data
        sub_folder = os.path.join(self.input_folder, "combined")
        if not os.path.exists(sub_folder):
            os.makedirs(sub_folder, exist_ok=True)
        file_path = os.path.join(sub_folder, f"combined_{date_str}.csv")
        df.to_csv(file_path, index=False)
        print(f"Combined data saved to {file_path}\n")

    def save_agg(self, df, file_name):
        """
        save the aggregated data in the output_folder/internal
        """
        # Ensure internal folder exists
        internal_path = os.path.join(self.output_folder, "internal")
        if not os.path.exists(internal_path):
            os.makedirs(internal_path, exist_ok=True)
            
        file_path = os.path.join(internal_path, file_name)
        df.to_csv(file_path, index=False)
        print(f"Aggregated data saved to {file_path}\n")

    def save_publish(self, df, file_name):
        """
        save the published data in the output_folder/publish
        """
        # Ensure publish folder exists
        publish_path = os.path.join(self.output_folder, "publish")
        if not os.path.exists(publish_path):
            os.makedirs(publish_path, exist_ok=True)
            
        file_path = os.path.join(publish_path, file_name)
        df.to_csv(file_path, index=False)
        print(f"Published data saved to {file_path}\n")

    def delete_old_capacity_file(self):
        """
        remove existing capacity file before saving the new one
        """
        for file in os.listdir(self.metadata_folder):
            if file.startswith("capacity_") and file.endswith(".csv"):
                file_path = os.path.join(self.metadata_folder, file)
                os.remove(file_path)
                print(f"The old file deleted: {file_path}")