# Test script that mimics the main.py pattern to test constraint data fetching
# This runs ONLY the fetch part for testing

import pandas as pd
import time
import urllib3
from urllib3.exceptions import InsecureRequestWarning

# Suppress only the single InsecureRequestWarning from urllib3
urllib3.disable_warnings(InsecureRequestWarning)

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from src.fetch_data import DataFetcher

# Disable SettingWithCopyWarning
pd.options.mode.chained_assignment = None


def test_constraint_fetch():
    """
    Test constraint data fetching using the main.py pattern
    """
    
    # Specify the base url
    base_url = "https://data.elexon.co.uk/bmrs/api/v1/"

    # Define dictionary for constraint endpoints (same pattern as original main.py)
    dict_ep = {
        "BID_ep": "balancing/settlement/acceptance/volumes/all/bid",  # volume of accepted bids
        "OFFER_ep": "balancing/settlement/acceptance/volumes/all/offer",  # volume of accepted offers
    }

    # Test dates
    start_date = "2025-08-15"
    end_date = "2025-08-22"
    
    print(f"Testing constraint data fetch from {start_date} to {end_date}")
    print("="*60)

    fetcher = DataFetcher(base_url)

    for day in pd.date_range(start=start_date, end=end_date):
        print(f"\n--- Fetching data for {day.strftime('%Y-%m-%d')} ---")
        
        ####### fetch and save the raw data by day #######
        for ep in dict_ep.keys():
            print(f"Fetching {ep}...")
            try:
                fetcher.fetch_data(dict_ep[ep], day)
                print(f"Successfully completed {ep}")
            except Exception as e:
                print(f"Error with {ep}: {str(e)}")

        # sleep for 0.1 second to avoid rate limiting
        time.sleep(0.1)
        
        print(f"Completed all endpoints for {day.strftime('%Y-%m-%d')}")

    print("\n" + "="*60)
    print("Test completed!")
    print("\nData should be saved in:")
    print("- data/input/BID/")
    print("- data/input/OFFER/")


if __name__ == "__main__":
    test_constraint_fetch()