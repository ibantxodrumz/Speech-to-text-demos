# Test script for price data fetching
# Tests the price data fetcher to get actual bid/offer prices for all BMUs

import sys
sys.path.append('src')  # Add src to path

import pandas as pd
import time
import urllib3
from urllib3.exceptions import InsecureRequestWarning

# Suppress only the single InsecureRequestWarning from urllib3
urllib3.disable_warnings(InsecureRequestWarning)

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Import directly from the file
from fetch_price_data import PriceDataFetcher

# Disable SettingWithCopyWarning
pd.options.mode.chained_assignment = None


def test_price_fetch():
    """
    Test function to fetch price data for all BMUs
    """
    
    # Specify the base url for Elexon API
    base_url = "https://data.elexon.co.uk/bmrs/api/v1/"
    
    # Test dates: 15/08/2025 to 16/08/2025
    start_date = "2025-08-15"
    end_date = "2025-08-22"
    
    print(f"Testing PRICE data fetch for all BMUs from {start_date} to {end_date}")
    print("="*70)
    
    # Initialize fetcher
    fetcher = PriceDataFetcher(base_url)
    
    # Fetch price data for each day
    for day in pd.date_range(start=start_date, end=end_date):
        print(f"\n--- Fetching PRICE data for {day.strftime('%Y-%m-%d')} ---")
        
        # Fetch market-wide prices for all BMUs
        print("Fetching market-wide bid/offer prices for ALL BMUs...")
        try:
            market_success = fetcher.fetch_market_prices(day)
            if market_success:
                print("Successfully processed market-wide price data")
            else:
                print("No market-wide price data available")
        except Exception as e:
            print(f"Error fetching market prices: {str(e)}")
        
        print(f"Completed price data fetch for {day.strftime('%Y-%m-%d')}")
        time.sleep(0.5)  # Small delay between days
    
    print("\n" + "="*70)
    print("Price data fetch test completed!")
    print("\nPrice data should be saved in:")
    print("- data/input/BALANCING_BID_OFFER_ALL_PRICES/")
    print("\nThis should contain actual bid/offer prices (£/MWh) for all market participants")
    print("Required for detecting price behavior changes during network constraints")


if __name__ == "__main__":
    test_price_fetch()