# Interconnector Reconciliation Tool (Release 1)

## Overview
This tool automates the reconciliation of position data for interconnector trading.

## Setup
1.  **Install Python**: Ensure Python 3.9+ is installed.
2.  **Install Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```

## Usage
1.  Place your data files in the `data/` folder.
2.  Run the tool:
    ```bash
    python click_2.py
    ```
3.  Check `outputs/` for results.

## Timezone Note
*   **Input**: Excel filenames ending in `_HH` are read as **Local UK Time**.
*   **Output**: CSV results are written in **Local UK Time**.
